# frozen_string_literal: false
# BlueCollar Systems — BUILT. NOT BOUGHT.
#
# SketchUp QA harness for PDF Vector Importer.
#
# Runs inside SketchUp (for example via -RubyStartup) and:
# 1) reads payload from ENV["BC_PDF_QA_PAYLOAD"]
# 2) loads extension entry points
# 3) runs pipeline import with selected preset/pages
# 4) writes JSON result to payload["result_json"]

require "json"
require "time"

module BCPDFQA
  module SketchUpHarness
    module_function

    def run
      payload_path = ENV["BC_PDF_QA_PAYLOAD"].to_s
      raise "BC_PDF_QA_PAYLOAD not set" if payload_path.strip.empty?
      payload = JSON.parse(File.read(payload_path))
      result_path = payload["result_json"].to_s
      raise "result_json missing in payload" if result_path.strip.empty?

      start_time = Time.now
      result = {
        "test_id" => payload["test_id"],
        "platform" => "SU",
        "status" => "ERROR",
        "message" => "",
        "started_at" => start_time.utc.iso8601
      }

      begin
        loader = require_extension(payload)
        importer = BlueCollarSystems::PDFVectorImporter

        model = Sketchup.active_model
        raise "No active SketchUp model" unless model

        before = model_entity_counts(model)
        before_layers = safe_layer_count(model)

        opts = build_opts(payload, importer)
        stats = importer.run_pipeline(model, payload["input_pdf"], opts)
        raise "run_pipeline returned nil" if stats.nil?

        after = model_entity_counts(model)
        after_layers = safe_layer_count(model)

        result["status"] = "PASS"
        result["message"] = "Import completed."
        result["loader"] = loader
        result["input_pdf"] = payload["input_pdf"]
        result["preset"] = payload["preset"]
        result["page_range"] = payload["page_range"]
        result["pipeline_stats"] = stats
        result["model_counts_before"] = before
        result["model_counts_after"] = after
        result["model_delta"] = hash_delta(after, before)
        result["layers_before"] = before_layers
        result["layers_after"] = after_layers
        result["layers_delta"] = after_layers - before_layers
      rescue => e
        result["status"] = "FAIL"
        result["message"] = "#{e.class}: #{e.message}"
        result["backtrace"] = (e.backtrace || [])[0, 25]
      ensure
        finish = Time.now
        result["finished_at"] = finish.utc.iso8601
        result["runtime_seconds"] = (finish - start_time).round(3)
        File.open(result_path, "w") { |f| f.write(JSON.pretty_generate(result)) }
      end
    end

    def build_opts(payload, importer)
      presets = importer::ImportDialog::PRESETS
      preset_name = payload["preset"].to_s.strip
      preset_name = "Full" if preset_name.empty?
      preset = presets[preset_name] || presets["Full"] || {}

      raw = {}
      preset.each { |k, v| raw[k] = v }
      raw[:pages] = payload["page_range"].to_s.strip.empty? ? "1" : payload["page_range"].to_s
      raw[:scale] = "1.0" if raw[:scale].to_s.strip.empty?

      importer::ImportDialog.send(:build_opts, raw)
    end

    def require_extension(payload)
      candidates = []
      ext_root = resolve_path(payload["extension_root"])
      plugins_dir = resolve_path(payload["plugins_dir"])

      if ext_root && !ext_root.empty?
        candidates << File.join(ext_root, "main")
        candidates << File.join(ext_root, "main.rb")
        candidates << File.join(File.dirname(ext_root), "bc_pdf_vector_importer.rb")
      end
      if plugins_dir && !plugins_dir.empty?
        candidates << File.join(plugins_dir, "bc_pdf_vector_importer", "main")
        candidates << File.join(plugins_dir, "bc_pdf_vector_importer", "main.rb")
        candidates << File.join(plugins_dir, "bc_pdf_vector_importer.rb")
      end

      candidates.each do |path|
        require path
        return path
      rescue LoadError
        next
      rescue StandardError
        next
      end

      if defined?(BlueCollarSystems::PDFVectorImporter) &&
         BlueCollarSystems::PDFVectorImporter.respond_to?(:run_pipeline)
        return "already_loaded"
      end

      raise "Could not load PDF Vector Importer from extension_root/plugins_dir."
    end

    def resolve_path(value)
      return nil if value.nil?
      s = value.to_s
      return nil if s.strip.empty?
      s = s.gsub(/%([^%]+)%/) { |m| ENV[$1] || m }
      File.expand_path(s)
    rescue
      value.to_s
    end

    def safe_layer_count(model)
      model.layers.length
    rescue
      0
    end

    def model_entity_counts(model)
      acc = {
        "edges" => 0,
        "faces" => 0,
        "groups" => 0,
        "component_instances" => 0,
        "texts" => 0,
        "images" => 0
      }
      count_entities(model.entities, acc, {})
      acc
    end

    def count_entities(entities, acc, seen_defs)
      entities.each do |e|
        if e.is_a?(Sketchup::Edge)
          acc["edges"] += 1
        elsif e.is_a?(Sketchup::Face)
          acc["faces"] += 1
        elsif defined?(Sketchup::Text) && e.is_a?(Sketchup::Text)
          acc["texts"] += 1
        elsif defined?(Sketchup::Image) && e.is_a?(Sketchup::Image)
          acc["images"] += 1
        elsif e.is_a?(Sketchup::Group)
          acc["groups"] += 1
          count_entities(e.entities, acc, seen_defs)
        elsif e.is_a?(Sketchup::ComponentInstance)
          acc["component_instances"] += 1
          d = e.definition
          next if d.nil?
          did = d.object_id
          next if seen_defs[did]
          seen_defs[did] = true
          count_entities(d.entities, acc, seen_defs)
        end
      end
    end

    def hash_delta(after, before)
      out = {}
      after.each do |k, v|
        out[k] = v.to_i - before[k].to_i
      end
      out
    end
  end
end

BCPDFQA::SketchUpHarness.run
